//---------------------------------------------------------------------------
// wzCoordCvt.h
// Author       :
// LastModify   :
// Comment      :
//---------------------------------------------------------------------------
#ifndef _WZCOORDCVT_H_
#define _WZCOORDCVT_H_
//---------------------------------------------------------------------------
#include <math.h>

#define PI           3.14159265358979
#define HALF_PI      PI/2.0
#define RADIAN       57.295779513082320876846364344191 // 180/PI
#define EPSLN        0.0000000001
#define S2R          4.84813681109536E-06              // sin(1")
#define dX_W2B       128
#define dY_W2B       -481
#define dZ_W2B       -664

/*---------------------------------------------------------------------------
system 0 : ������ (��)
       1 : ������ (��)
       2 : ������ (��)
       3 : TM - ���ο���(125)
       4 : TM - �ߺο���(127)
       5 : TM - ���ο���(129)
       6 : KATEC ��ǥ��(128)
       7 : UTM Zone52(129)
       8 : UTM Zone51(123)
       9 : ITRF2000
---------------------------------------------------------------------------*/
static int    sys[]   = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
// ellips 0 : Bessel1841  
//        1 : WGS84       
static int    elli[]  = { 0, 1 };
static double major[] = { 6377397.155,   6378137.0    };	// Major axis of Bessel1841 and WGS84
static double minor[] = { 6356078.96325, 6356752.3142 }; 	// Minor axis of Bessel1841 and WGS84
// Scale reduction factor 
static double SF[]    = { 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.9999, 0.9996, 0.9996, 1.0};

// Longitude center (Radian)
static double LonCen[] = { 	0.0, 
							0.0, 
							0.0,
							2.18171200985643, 
							2.21661859489632, 
                          	2.2515251799362, 
                          	2.23402144255274, 
                          	2.25147473507269,
                          	2.14675497995303,
                          	2.2165681500327985626930872759805 };
// Latitude origin    
static double LatCen[] = {	0.0, 
							0.0, 
							0.0, 
							0.663225115757845, 
							0.663225115757845,
							0.663225115757845, 
							0.663225115757845, 
							0.0, 
							0.0,
							0.663225115757845 };
    
// False northing
static long FN[] = { 0, 0, 0, 500000, 500000, 500000, 600000, 0, 0, 500000 };
// False easting
static long FE[] = { 0, 0, 0, 200000, 200000, 200000, 400000, 500000, 500000, 200000 };

enum GeoEllips { kBessel1841=0, kWgs84=1 };
enum GeoSystem { kGeoDeg=0, kGeoDegMin=1, kGeoDegSec=2, kTmWest=3, kTmMid=4, kTmEast=5, kKatec=6, kUtm52=7, kUtm51=8, Itrf2000=9 };

//---------------------------------------------------------------------------
typedef struct{
    short  prepare;
	int    ind;           		// spherical flag
	double r_major;       		// major axis
	double r_minor;       		// minor axis
	double scale_factor;  		// scale reduction factor
	double lon_center;    		// center longitude (projection center) in radian
	double lat_origin;    		// center latitude in radian
	double false_northing;		// y offset in meters
	double false_easting; 		// x offset in meters
	double e0;            		// eccentricity constants
	double e1;            		// eccentricity constants
	double e2;            		// eccentricity constants
	double e3;            		// eccentricity constants
	double e;             		// eccentricity constants
	double es;            		// eccentricity constants
	double esp;           		// eccentricity constants
	double ml0;           		// small value m
} COORDPARAMS, *LPCOORDPARAMS;

//---------------------------------------------------------------------------
double _e0fn(double x);
double _e1fn(double x);
double _e2fn(double x);
double _e3fn(double x);
double _e4fn(double x);
double _mlfn(double e0, double e1, double e2, double e3, double phi);
double _acos(double x);
double _asin(double x);
double _asinz(double con);
double _dabs(double x);
double _dms2d(int kd, int km, double ks);
double _ms2d( int km, double ks);
double _ldms2d(long ldms);
double _dm2d(double dm);

void _d2dms(double* Lon, double* Lat, int* LonMin, double* LonSec, int* LatMin, double* LatSec);
void _DatumTrans(double input_a,  double input_b,  double input_phi,   double input_lamda,   double input_h, 
                 double output_a, double output_b, double* output_phi, double* output_lamda, double* output_h, 
                 short delta_x, short delta_y, short delta_z);

void _SetParam( LPCOORDPARAMS p, double r_maj, double r_min, double scale_fact,
                double center_lon, double center_lat,
                double false_east, double false_north );

int  _ConvertTMToLL( LPCOORDPARAMS p, double lon, double lat, double* x,   double* y);
int  _ConvertLLToTM( LPCOORDPARAMS p, double x,   double y,   double* lon, double* lat);

int  _ConvertIn( LPCOORDPARAMS p, double* x, double* y, int e1, int s1);
int  _ConvertOut(LPCOORDPARAMS p, double* lon_temp, double* lat_temp, double* h, int e1, int e2, int s1, int s2);

int  fnCoordConvert( double* outX, double* outY,
                     int inEllips, int inSystem, int outEllips, int outSystem);
int  fnCoordConvert( LPCOORDPARAMS p, double* outX, double* outY,
               		 int inEllips, int inSystem, int outEllips, int outSystem );                     

unsigned short _calDist(double sx, double sy, double ex, double ey);
long _calDist2(double sx, double sy, double ex, double ey, double rx, double ry, long rdst);
unsigned short _calDegree(long sx, long sy, long ex, long ey);

void fnDegreeToGps(double mX, double mY, double* gX, double* gY);
void fnGpsToDegree(double gX, double gY, double* mX, double* mY);
//---------------------------------------------------------------------------
#endif