//---------------------------------------------------------------------------
#ifndef wzRWLockH
#define wzRWLockH

#include <windows.h>
//---------------------------------------------------------------------------
class wzRWLock
{
private:
    CRITICAL_SECTION readerCountLock;
    CRITICAL_SECTION writerLock;
    HANDLE noReaders;
    int readerCount;

protected:

public:
    __fastcall wzRWLock();
    __fastcall ~wzRWLock();

    int  __fastcall getReaderCount();
    void __fastcall rdLock();
    void __fastcall wrLock();
    void __fastcall rdUnlock();
    void __fastcall wrUnlock();

};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------

